#include <iostream>
using namespace std;

class Buscar
{
public:
Bucar ()= default;
~Buscar();

int busquedaSecuencial();
int busquedaOrden1();
int busquedaOrden2();
int binarySearch();

};
/*#include <iostream>
#include <vector>
using namespace std;
template <typename T>
class Busqueda{
public:
Busqueda ()= default;
~Busqueda();

int busquedaSecuencial();
int busquedaOrden1();
int busquedaOrden2();
int binarySearch();

}
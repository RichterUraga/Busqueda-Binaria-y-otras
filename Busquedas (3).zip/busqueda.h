/*#include <iostream>
using namespace std;
template <typename T>
class Buscar
{
public:
Bucar ()= default;
~Buscar();

int busquedaSecuencial(vector<T>v, int termino);
int busquedaOrden1(vector<T>v, int termino);
int busquedaOrden2(vector<T>v, int termino);
int binarySearch(vector<T>v, int termino);

};

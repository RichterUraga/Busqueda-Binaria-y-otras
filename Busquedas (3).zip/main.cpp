#include <iostream>
#include <vector>
#include <chrono>
#include <algorithm>
#include <random>
//#include "busqueda.h"
using namespace std;
using namespace std::chrono;

//int Buscar::
int busquedaSecuencial(vector<int> v, int termino){
	for(int i=0; i<v.size(); i++){
		if(v[i]==termino){
			return i;
		}
	}
	return -1;
}

//int Buscar::
int busquedaOrden1(vector<int> v, int termino){
	for(int i=0; i<v.size(); i++){
		if(v[i]>termino){
			return -1;
		}
		if(v[i]==termino){
			return i;
		}
	}
	return -1;
}

//int Buscar::
int busquedaOrden2(vector<int> v, int termino){
	int paso=2;
	int inicio=0;
	int fin;
	while(inicio<v.size()){
		fin=inicio+paso;
		if(fin>v.size()){
			fin=v.size();
		}
		if(v[fin-1]>=termino){
			for(int i=inicio; i<fin; i++){
				if(v[i]==termino){
					return i;
				}
			}
			return -1;
		}
		inicio=fin;
	}
	return -1;
}

//int Buscar::
int binarySearch(vector<int>v, int termino){
	int inicio=0;
	int fin=v.size()-1;
	if(termino>v[fin] || termino<v[inicio]){
		return -1;
	}
	while(fin>=inicio){
		int medio=(inicio+fin)/2;
		if(v[medio]==termino){
			return medio;
		}else if(termino>v[medio]){
			inicio=medio+1;
		}else{
			fin=medio-1;
		}
	}
	return -1;
}

int main(){
	vector<int> v;
	std::default_random_engine generator;
	std::uniform_int_distribution<int> distribution(1,10000000);
	for(int i=0; i<1000000; i++){
		//a.push_back(i);
		v.push_back(distribution(generator));
	}
	
	sort(v.begin(), v.end());
	int termino =v[55344];
	int x;
	//Busqueda secuencial
	cout<<"Busqueda Secuencial: ";
	auto inicio=high_resolution_clock::now();
	x=busquedaSecuencial(v,termino);
	auto fin=high_resolution_clock::now();
	auto tiempo=duration_cast<microseconds>(fin - inicio).count();
	cout<<"El numero es ....: "<<x<<", tiempo en micro segundos: "<<tiempo<<endl;
	//Busqueda Ordenada 1
	cout<<"Busqueda Ordenada 1 : ";
	inicio=high_resolution_clock::now();
	x=busquedaOrden1(v,termino);
	fin=high_resolution_clock::now();
	tiempo=duration_cast<microseconds>(fin - inicio).count();
	cout<<"El número es....: "<<x<<", tiempo en micro segundos: "<<tiempo<<endl;
	//Busqueda Ordenada 2
	cout<<"Ordenada 2 :";
	inicio=high_resolution_clock::now();
	x=busquedaOrden2(v,termino);
	fin=high_resolution_clock::now();
	tiempo=duration_cast<microseconds>(fin - inicio).count();
	cout<<"El número es .....: "<<x<<", tiempo en microsegundos: "<<tiempo<<endl;
	//Busqueda binaria
	cout<<"Busqueda Binaria :";
	inicio=high_resolution_clock::now();
	x=binarySearch(v,termino);
	fin=high_resolution_clock::now();
	tiempo=duration_cast<microseconds>(fin - inicio).count();
	cout<<"El numero es.....: "<<x<<", tiempo en microsegundos: "<<tiempo<<endl;
	return 0;
}